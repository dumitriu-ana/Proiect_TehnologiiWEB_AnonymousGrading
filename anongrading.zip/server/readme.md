se deschide terminal nou
cd server
npm init     
npm i sqlite3
npm install --save sequelize
npm install --save sqlite3
sequelize init
npm install express
npm install --save mysql2
npm install bcrypt
npm install jsonwebtoken
npm install cors
npm install joi 
npm install joi-password-complexity
